"""Fixed settings for the SciData-Forge correspondence-test pilot.

Every value here is set in advance. Changing any of them changes the pilot.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
STRUCT = ROOT / "structures"
RESULTS = ROOT / "results"

MOLECULES_CSV = DATA / "molecules.csv"
ELEMENTS = ["H", "C", "N", "O"]

# Electronic-structure settings (restricted Kohn-Sham, closed shell)
GRID_LEVEL = 3
CONV_TOL = 1e-9  # hartree
DENSITY_FIT = True

# Geometry optimization method; all methods are then evaluated at these geometries.
OPT_METHOD = "PBE/def2-SVP"

# Method label -> (PySCF xc string, basis)
METHODS = {
    "PBE/def2-SVP": ("PBE", "def2-svp"),
    "RPBE/def2-TZVP": ("GGA_X_RPBE,GGA_C_PBE", "def2-tzvp"),
    "B3LYP/def2-TZVP": ("B3LYP", "def2-tzvp"),
}

# Method pairs (A, B); the energy difference is E_B - E_A.
PAIRS = [
    ("RPBE/def2-TZVP", "B3LYP/def2-TZVP"),
    ("PBE/def2-SVP", "RPBE/def2-TZVP"),
    ("PBE/def2-SVP", "B3LYP/def2-TZVP"),
]

# Displaced geometries for force comparison
N_DISPLACED = 2
DISPLACEMENT_SIGMA = 0.05  # angstrom, Gaussian noise on every Cartesian coordinate
RANDOM_SEED = 20261023
EMBED_SEED = 42

# Thresholds fixed before analysis
ENERGY_THRESHOLD_EV = 0.05    # eV per molecule, mean absolute error on withheld families
FORCE_THRESHOLD_EV_A = 0.05   # eV/angstrom, reference force-error target
MIN_FORCE_FOR_ANGLE = 1e-3    # eV/angstrom; smaller vectors are excluded from angle statistics

# Unit conversions (CODATA 2018)
HARTREE_TO_EV = 27.211386245988
BOHR_TO_ANGSTROM = 0.529177210903
