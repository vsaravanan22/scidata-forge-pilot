"""Step 3: energy correspondence by leave-one-family-out cross-validation,
and force comparison at identical geometries. Writes the pilot table.

Energy models for each method pair (Delta E = E_B - E_A, eV):
  constant offset:      Delta E ~ c
  per-element offsets:  Delta E ~ sum_el n_el * c_el   (OLS, no intercept)
Each chemical family is withheld in turn; errors are pooled over all withheld molecules.

Outputs:
  results/energies.csv, results/lofo_folds.csv, results/forces_summary.csv
  results/table3.csv, results/table3.md
"""
import csv
import json
import sys

import numpy as np
import pandas as pd
from rdkit import Chem

import settings as S

RAW = S.RESULTS / "raw"


def safe(label):
    return label.replace("/", "_")


def element_counts(smiles):
    mol = Chem.AddHs(Chem.MolFromSmiles(smiles))
    counts = {el: 0 for el in S.ELEMENTS}
    for a in mol.GetAtoms():
        counts[a.GetSymbol()] += 1
    return [counts[el] for el in S.ELEMENTS]


def lofo(delta, X, families):
    """Return pooled absolute errors for both models and per-fold MAEs."""
    err_const, err_elem, folds = [], [], []
    for fam in sorted(set(families)):
        test = families == fam
        train = ~test
        c = delta[train].mean()
        e_const = np.abs(delta[test] - c)
        coef, *_ = np.linalg.lstsq(X[train], delta[train], rcond=None)
        e_elem = np.abs(delta[test] - X[test] @ coef)
        err_const.extend(e_const)
        err_elem.extend(e_elem)
        folds.append({"withheld_family": fam, "n_train": int(train.sum()),
                      "n_test": int(test.sum()),
                      "mae_constant_ev": e_const.mean(), "mae_per_element_ev": e_elem.mean(),
                      **{f"offset_{el}_ev": v for el, v in zip(S.ELEMENTS, coef)}})
    return np.mean(err_const), np.mean(err_elem), folds


def force_stats(names, ma, mb):
    diffs, angles = [], []
    for name in names:
        for k in range(S.N_DISPLACED):
            fa = np.load(RAW / f"forces__{safe(ma)}__{name}_{k}.npy")
            fb = np.load(RAW / f"forces__{safe(mb)}__{name}_{k}.npy")
            diffs.extend(np.abs(fa - fb).ravel())
            na, nb = np.linalg.norm(fa, axis=1), np.linalg.norm(fb, axis=1)
            ok = (na > S.MIN_FORCE_FOR_ANGLE) & (nb > S.MIN_FORCE_FOR_ANGLE)
            cos = np.sum(fa[ok] * fb[ok], axis=1) / (na[ok] * nb[ok])
            angles.extend(np.degrees(np.arccos(np.clip(cos, -1.0, 1.0))))
    return float(np.mean(diffs)), float(np.mean(angles))


def main():
    mols = pd.read_csv(S.MOLECULES_CSV)
    names = list(mols["name"])
    families = mols["family"].to_numpy()
    X = np.array([element_counts(s) for s in mols["smiles"]], dtype=float)

    energies = {}
    for method in S.METHODS:
        energies[method] = np.array([
            json.loads((RAW / f"energy__{safe(method)}__{n}.json").read_text())["energy_ev"]
            for n in names])
    pd.DataFrame({"molecule": names, "family": families,
                  **{m: energies[m] for m in S.METHODS}}).to_csv(
        S.RESULTS / "energies.csv", index=False, float_format="%.8f")

    table, all_folds, force_rows = [], [], []
    for ma, mb in S.PAIRS:
        delta = energies[mb] - energies[ma]
        mae_c, mae_e, folds = lofo(delta, X, families)
        fdiff, fang = force_stats(names, ma, mb)
        energy_class = ("Comparable after correction" if mae_e < S.ENERGY_THRESHOLD_EV
                        else "Incompatible")
        force_class = ("Directly comparable" if fdiff < S.FORCE_THRESHOLD_EV_A
                       else "Incompatible")
        pair = f"{ma} and {mb}"
        table.append({"method_pair": pair,
                      "energy_mae_constant_ev": round(mae_c, 3),
                      "energy_mae_per_element_ev": round(mae_e, 3),
                      "energy_class": energy_class,
                      "force_mad_ev_per_a": round(fdiff, 3),
                      "mean_force_angle_deg": round(fang, 1),
                      "force_class": force_class})
        for f in folds:
            all_folds.append({"method_pair": pair, **f})
        force_rows.append({"method_pair": pair, "force_mad_ev_per_a": fdiff,
                           "mean_force_angle_deg": fang})

    pd.DataFrame(all_folds).to_csv(S.RESULTS / "lofo_folds.csv", index=False, float_format="%.6f")
    pd.DataFrame(force_rows).to_csv(S.RESULTS / "forces_summary.csv", index=False, float_format="%.6f")
    t = pd.DataFrame(table)
    t.to_csv(S.RESULTS / "table3.csv", index=False)

    md = ["| Method pair | Energy error, constant offset (eV) | Energy error, per-element offsets (eV) "
          "| Energy class | Force difference (eV/Å) | Mean force angle (deg) |",
          "|---|---|---|---|---|---|"]
    for r in table:
        md.append(f"| {r['method_pair']} | {r['energy_mae_constant_ev']:.2f} | "
                  f"{r['energy_mae_per_element_ev']:.3f} | {r['energy_class']} | "
                  f"{r['force_mad_ev_per_a']:.2f} | {r['mean_force_angle_deg']:.0f} |")
    md.append("")
    md.append(f"Energy errors are mean absolute errors on withheld chemical families "
              f"(threshold {S.ENERGY_THRESHOLD_EV} eV). Force reference threshold "
              f"{S.FORCE_THRESHOLD_EV_A} eV/Å.")
    (S.RESULTS / "table3.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    return 0


if __name__ == "__main__":
    sys.exit(main())
