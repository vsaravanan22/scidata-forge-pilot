"""Step 2: evaluate every method at identical geometries.

Energies at the optimized geometries; analytic forces at the displaced geometries.
Results are cached per (molecule, method, geometry), so the step can be resumed.

Outputs:
  results/raw/energy__<method>__<name>.json
  results/raw/forces__<method>__<name>_<k>.npy   (eV/angstrom, natoms x 3)
"""
import csv
import json
import sys

import numpy as np
from pyscf import dft, gto

import settings as S

RAW = S.RESULTS / "raw"


def read_xyz(path):
    lines = path.read_text().splitlines()[2:]
    symbols = [l.split()[0] for l in lines]
    coords = np.array([[float(x) for x in l.split()[1:4]] for l in lines])
    return symbols, coords


def make_rks(symbols, coords, xc, basis):
    mol = gto.M(atom=[[s, tuple(c)] for s, c in zip(symbols, coords)], basis=basis,
                unit="Angstrom", charge=0, spin=0, verbose=0)
    mf = dft.RKS(mol)
    mf.xc = xc
    mf.grids.level = S.GRID_LEVEL
    mf.conv_tol = S.CONV_TOL
    if S.DENSITY_FIT:
        mf = mf.density_fit()
    return mf


def safe(label):
    return label.replace("/", "_")


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    with open(S.MOLECULES_CSV) as f:
        names = [r["name"] for r in csv.DictReader(f)]
    for method, (xc, basis) in S.METHODS.items():
        for name in names:
            epath = RAW / f"energy__{safe(method)}__{name}.json"
            if not epath.exists():
                symbols, coords = read_xyz(S.STRUCT / "opt" / f"{name}.xyz")
                mf = make_rks(symbols, coords, xc, basis)
                e = mf.kernel()
                if not mf.converged:
                    raise RuntimeError(f"SCF not converged: {method} {name}")
                epath.write_text(json.dumps({"molecule": name, "method": method,
                                             "energy_hartree": e,
                                             "energy_ev": e * S.HARTREE_TO_EV}))
            for k in range(S.N_DISPLACED):
                fpath = RAW / f"forces__{safe(method)}__{name}_{k}.npy"
                if fpath.exists():
                    continue
                symbols, coords = read_xyz(S.STRUCT / "displaced" / f"{name}_{k}.xyz")
                mf = make_rks(symbols, coords, xc, basis)
                mf.kernel()
                if not mf.converged:
                    raise RuntimeError(f"SCF not converged: {method} {name}_{k}")
                grad = mf.nuc_grad_method().kernel()  # hartree/bohr
                forces = -grad * S.HARTREE_TO_EV / S.BOHR_TO_ANGSTROM
                np.save(fpath, forces)
            print(f"[done] {method:16s} {name}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
