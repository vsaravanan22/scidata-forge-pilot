"""Step 1: build starting structures with RDKit, optimize at PBE/def2-SVP,
and generate displaced geometries for the force comparison.

Outputs:
  structures/opt/<name>.xyz               optimized geometries (angstrom)
  structures/displaced/<name>_<k>.xyz     displaced geometries (angstrom)
"""
import csv
import sys

import numpy as np
from pyscf import dft, gto
from pyscf.geomopt.berny_solver import optimize
from rdkit import Chem
from rdkit.Chem import AllChem

import settings as S


def rdkit_start(smiles):
    mol = Chem.AddHs(Chem.MolFromSmiles(smiles))
    if mol.GetNumAtoms() > 1:
        if AllChem.EmbedMolecule(mol, randomSeed=S.EMBED_SEED) != 0:
            raise RuntimeError(f"embedding failed for {smiles}")
        if AllChem.MMFFHasAllMoleculeParams(mol):
            AllChem.MMFFOptimizeMolecule(mol)
        else:
            AllChem.UFFOptimizeMolecule(mol)
        pos = mol.GetConformer().GetPositions()
    else:
        pos = np.zeros((1, 3))
    symbols = [a.GetSymbol() for a in mol.GetAtoms()]
    return symbols, np.asarray(pos)


def make_mol(symbols, coords, basis):
    atoms = [[s, tuple(c)] for s, c in zip(symbols, coords)]
    return gto.M(atom=atoms, basis=basis, unit="Angstrom", charge=0, spin=0, verbose=0)


def make_rks(mol, xc):
    mf = dft.RKS(mol)
    mf.xc = xc
    mf.grids.level = S.GRID_LEVEL
    mf.conv_tol = S.CONV_TOL
    if S.DENSITY_FIT:
        mf = mf.density_fit()
    return mf


def write_xyz(path, symbols, coords, comment=""):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write(f"{len(symbols)}\n{comment}\n")
        for s, c in zip(symbols, coords):
            f.write(f"{s:2s} {c[0]: .10f} {c[1]: .10f} {c[2]: .10f}\n")


def main():
    xc, basis = S.METHODS[S.OPT_METHOD]
    with open(S.MOLECULES_CSV) as f:
        rows = list(csv.DictReader(f))
    for idx, row in enumerate(rows):
        name = row["name"]
        out = S.STRUCT / "opt" / f"{name}.xyz"
        if out.exists():
            print(f"[skip] {name} already optimized", flush=True)
        else:
            symbols, start = rdkit_start(row["smiles"])
            mol = make_mol(symbols, start, basis)
            mol_eq = optimize(make_rks(mol, xc), maxsteps=100)
            coords = mol_eq.atom_coords(unit="Angstrom")
            write_xyz(out, symbols, coords, f"{name} optimized at {S.OPT_METHOD}")
            print(f"[opt ] {name}", flush=True)

        # Displaced geometries, reproducible per molecule
        lines = out.read_text().splitlines()[2:]
        symbols = [l.split()[0] for l in lines]
        coords = np.array([[float(x) for x in l.split()[1:4]] for l in lines])
        for k in range(S.N_DISPLACED):
            rng = np.random.default_rng([S.RANDOM_SEED, idx, k])
            disp = coords + rng.normal(0.0, S.DISPLACEMENT_SIGMA, coords.shape)
            write_xyz(S.STRUCT / "displaced" / f"{name}_{k}.xyz", symbols, disp,
                      f"{name} displaced {k}, sigma={S.DISPLACEMENT_SIGMA} A")
    return 0


if __name__ == "__main__":
    sys.exit(main())
